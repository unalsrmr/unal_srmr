#ifndef WORLD_H
#define WORLD_H
#include"Robot.h"
#include<iostream>
#include<cstdlib>
using namespace std;
const int WORLDSIZE = 10;
class World {
    friend class Robot;

private:
    Robot* grid[WORLDSIZE][WORLDSIZE];//2D array of pointers to Robot objects

public:
    World();
    ~World();
    Robot* getAt(int x, int y);//Pointer to the Robot object at grid[x][y], or nullptr if no robot in the grid
    void setAt(int x, int y, Robot* rob);//rob: Pointer to the Robot object to be placed or nullptr if it isnot robot
    void Display();//Display the winning Robot in the world grid
    void simulation();//Perform simulation of robots' movement and interactions
    bool control()const;//Check if only one robot remains in the world
    void printBoard()const;//Print the current state of the world grid to the console
    int again(int i,int j,int dir);//Determine a valid direction for movement if the initial direction is out of bounds
};

#endif
