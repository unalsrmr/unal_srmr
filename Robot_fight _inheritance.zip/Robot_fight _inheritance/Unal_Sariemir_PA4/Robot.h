#ifndef ROBOT_H
#define ROBOT_H
#include<string>
#include<iostream>
using namespace std;
class World;

class Robot {
protected:
    int type;//Type
    int hit_point;//Hit Point
    int strength;//Damage
    bool moved;//İs moved for each simulation
    std::string name;
    World* world;
public:
    Robot();
    Robot(World* wrld,int newType,int newStrength,int newHit,std::string name);
    virtual ~Robot(){}
    virtual int getDamage()const = 0;//Virtual function to get the damage inflicted by the robot
    virtual int getHitpoint()const = 0;//Virtual function to get the hit points of the robot
    virtual void setHitpoint(int newHit)=0;//Virtual function to set the hit points of the robot
    virtual std::string get_name()const = 0;//Virtual function to get the name of the robot
    bool getMoved()const;//Returns true if the robot has moved
    void setMoved(bool is_moved);//Marks the robot as moved
    int getType(){return type;};//Return the type of the robot
    void move(int i,int j,int dir,World *wrld);//Moves the robot in a specified direction within the world
    Robot *fight(Robot *rob);//Returns the winning robot or nullptr if there's no winner
};

#endif
