#ifndef ROBOCOP_H
#define ROBOCOP_H
#include"Humanic.h"
class Robocop:public Humanic{
public:
    Robocop();//Constructors
    Robocop(World *wrld,int newType,int newStrength,int newHit,std::string name);
    int getDamage()const override;//Return Damage
    std::string get_name()const override;//Return name
    int getHitpoint()const override;//Return Hit Point
    int tactical_nuke_attack()const override;//Return 1 if tactical nuke attack occurs
    void setHitpoint(int newHit)override;//Set new HitPoint
    ~Robocop();
};

#endif