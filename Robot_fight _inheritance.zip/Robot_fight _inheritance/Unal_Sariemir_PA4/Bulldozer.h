#ifndef BULLDOZER_H
#define BULLDOZER_H
#include"Robot.h"
class BullDozer:public Robot{
public:
    BullDozer();
    BullDozer(World* wrld,int newType,int newStrength,int newHit,std::string name);
    int getDamage()const override;//Return Damage
    std::string get_name()const override;//Return name
    int getHitpoint()const override;//Return HitPoint
    void setHitpoint(int newHit) override;//Set new Hit Point
    ~BullDozer();
};
#endif