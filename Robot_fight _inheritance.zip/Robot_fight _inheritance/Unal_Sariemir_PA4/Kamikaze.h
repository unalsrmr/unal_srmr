#ifndef KAMIKAZE_H
#define KAMIKAZE_H
#include "Robot.h"
class Kamikaze:public Robot{
public:
    Kamikaze();
    Kamikaze(World* wrld,int newType,int newStrength,int newHit,std::string name);
    int getDamage()const override;//Return the damage
    int getHitpoint()const override;//Return the Hit Point 
    std::string get_name()const override;//Return the name
    void setHitpoint(int newHit)override;//Set the new Hit Point
    ~Kamikaze();
};

#endif 
