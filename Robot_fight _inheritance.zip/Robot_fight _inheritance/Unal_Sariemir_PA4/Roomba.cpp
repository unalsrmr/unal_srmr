#include"Roomba.h"
Roomba::Roomba():Robot(){}//Constructors
Roomba::Roomba(World *wrld,int newType,int NewStrength,int NewHit,std::string name)
    :Robot(wrld,newType,NewStrength,NewHit,name){}
std::string Roomba::get_name()const{return name;}//Return name
int Roomba::getDamage()const{//Getter for damage (random damage calculation based on Roomba's strength)
    int damage;
    damage = rand()%strength+1;
    return damage;
}
int Roomba::getHitpoint()const{return hit_point;}//Return HitPoint
void Roomba::setHitpoint(int newHit){hit_point = newHit;}
Roomba::~Roomba(){}