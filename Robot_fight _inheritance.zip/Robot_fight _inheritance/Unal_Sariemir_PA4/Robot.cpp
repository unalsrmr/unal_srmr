#include"Robot.h"
#include"World.h"
Robot::Robot()
    :world(nullptr), strength(0), moved(false), hit_point(0), type(0){}
// Constructor with parameters
Robot::Robot(World* wrld, int newType, int newStrength, int newHit, std::string name)
    :world(wrld), type(newType), strength(newStrength), hit_point(newHit), name(name), moved(false) {}
bool Robot::getMoved()const{return moved;}
void Robot::setMoved(bool is_moved){moved = is_moved;}
void Robot::move(int i,int j,int dir,World *wrld){//Method to move the robot in the given direction
    /*1 for left, 2 for up, 3 for right, 4 for down*/
    this->moved = true;
    if(dir==1){/*LEFT*/
        while((wrld->getAt(i,j-1)==nullptr)&&j>0){
            wrld->setAt(i,j,nullptr);//Clear the current position
            wrld->setAt(i,j-1,this); //Set the new position
            j--;//Update the column index
        }
        //If there's a robot in the new position, initiate a fight
        if((wrld->getAt(i,j-1)!=nullptr)){
            wrld->setAt(i,j-1,this->fight(wrld->getAt(i,j-1)));//Return the winners robot
            wrld->setAt(i,j,nullptr);//Remove the loser robot
        }
    }
    else if(dir==2){/*UP*/
        while((wrld->getAt(i-1,j)==nullptr)&&i>0){
            wrld->setAt(i,j,nullptr);//Clear the current position
            wrld->setAt(i-1,j,this); //Set the new position
            i--;//Update the row index
        }
        //If there's a robot in the new position,initiate a fight
        if((wrld->getAt(i-1,j)!=nullptr)){
            wrld->setAt(i-1,j,this->fight(wrld->getAt(i-1,j)));//Return the winners robot
            wrld->setAt(i,j,nullptr);//Remove the loser robot
        }
    }
    else if(dir==3){/*sağ*/
        while((wrld->getAt(i,j+1)==nullptr)&&j<WORLDSIZE-1){
            wrld->setAt(i,j,nullptr);//Clear the current position
            wrld->setAt(i,j+1,this); //Set the new position
            j++;
        }
        //If there's a robot in the new position,initiate a fight
        if((wrld->getAt(i,j+1)!=nullptr)){
            wrld->setAt(i,j+1,this->fight(wrld->getAt(i,j+1)));
            wrld->setAt(i,j,nullptr);//Remove the loser robot
        }
    }
    else if(dir==4){/*aşağı*/
        while((wrld->getAt(i+1,j)==nullptr)&&i<WORLDSIZE-1){
            wrld->setAt(i,j,nullptr);//Clear the current position
            wrld->setAt(i+1,j,this); //Set the new position
            i++;
        }
        //If there's a robot in the new position,initiate a fight
        if((wrld->getAt(i+1,j)!=nullptr)){
            wrld->setAt(i+1,j,this->fight(wrld->getAt(i+1,j)));
            wrld->setAt(i,j,nullptr);//Remove the loser robot
        }
    }
}
//Method to simulate a fight between two robots
//Return the winner
Robot* Robot::fight(Robot* rob){
    // Check if this robot is already defeated
    int newHit;int DamageTwice;int damage;
    if(this->getDamage()<=0){
        cout<<this->get_name()<<" is DEAD"<<endl;
        return rob;
    }
    if(rob->getDamage()<=0){
        cout<<rob->get_name()<<" is DEAD"<<endl;
        return this;
    }
    damage = this->getDamage();
    cout << this->get_name() << "(" << this->getHitpoint() << ") hits " << rob->get_name();
    cout << "(" << rob->getHitpoint() << ") with " << damage << endl;

    // Double the damage if this robot's type is roomba
    if(this->getType() == 2){//ROOMBA
        DamageTwice = this->getDamage();
        cout << this->get_name() << "(" << this->getHitpoint() << ") hits " << rob->get_name();
        cout << "(" << rob->getHitpoint() << ") with " << DamageTwice << endl;
        damage = damage+DamageTwice;
    }   
    if(this->getType() == 4){//KAMIKAZE
        this->setHitpoint(0);
        cout << "The new hitpoints of " << this->get_name() << " is " << this->getHitpoint() << endl;
        newHit = rob->getHitpoint()-damage;
        // Kamikaze vs. other robot types
        if(newHit<=0){
            rob->setHitpoint(0);
            cout << "The new hitpoints of " << rob->get_name() << " is " << rob->getHitpoint() << endl;
            cout<<this->get_name()<<" is DEAD"<<endl;
            cout<<rob->get_name()<<" is DEAD"<<endl<<endl;
            return nullptr;//No winner
        }
        else{
            rob->setHitpoint(newHit);
            cout << "The new hitpoints of " << rob->get_name() << " is " << rob->getHitpoint() << endl;
            cout<<this->get_name()<<" is DEAD"<<endl<<endl;
            return rob;//Return opponent as winner
        }
    }   
    // Reduce rob robot's hitpoints
    newHit = rob->getHitpoint() - damage;
    if(newHit <= 0){
        rob->setHitpoint(0);
        cout << "The new hitpoints of " << rob->get_name() << " is " << rob->getHitpoint() << endl;
        cout<<rob->get_name()<<" is DEAD"<<endl<<endl;
        return this;//this wins
    }else{
        rob->setHitpoint(newHit);//Reduce opponent's hitpoints
    }
    cout << "The new hitpoints of " << rob->get_name() << " is " << rob->getHitpoint() << endl;

    // Perform counterattack by opponent rob robot
    damage = rob->getDamage();
    cout << rob->get_name() << "(" << rob->getHitpoint() << ") hits " << this->get_name();
    cout << "(" << this->getHitpoint() << ") with " << damage << endl;

    // Double the damage if `rob` robot's type is robocop
    if(rob->getType() == 2){//ROOMBA
        DamageTwice = rob->getDamage();
        cout << rob->get_name() << "(" << rob->getHitpoint() << ") hits " << this->get_name();
        cout << "(" << this->getHitpoint() << ") with " << DamageTwice << endl;
        damage = damage+DamageTwice;
    }   
    if(rob->getType() == 4){//KAMIKAZE
        rob->setHitpoint(0);
        cout << "The new hitpoints of " << rob->get_name() << " is " << rob->getHitpoint() << endl;
        newHit = this->getHitpoint()-damage;
        // Kamikaze vs. other robot types
        if(newHit<=0){
            this->setHitpoint(0);
            cout << "The new hitpoints of " << this->get_name() << " is " << this->getHitpoint() << endl;
            cout<<rob->get_name()<<" is DEAD"<<endl;
            cout<<this->get_name()<<" is DEAD"<<endl<<endl;
            return nullptr;//No winner
        }
        else{
            this->setHitpoint(newHit);
            cout << "The new hitpoints of " << this->get_name() << " is " << this->getHitpoint() << endl;
            cout<<rob->get_name()<<" is DEAD"<<endl<<endl;
            return this;//Return opponent as winner
        }
    }   
    // Reduce this robot's hitpoints
    newHit = this->getHitpoint() - damage;
    if(newHit <= 0){
        this->setHitpoint(0);
        cout << "The new hitpoints of " << this->get_name() << " is " << this->getHitpoint() << endl;
        cout<<this->get_name()<<" is DEAD"<<endl<<endl;
        return rob; //rob wins
    }else{
        this->setHitpoint(newHit);
    }
    cout << "The new hitpoints of " << this->get_name() << " is " << this->getHitpoint() << endl;
    //Check if this robot is defeated after rob robot's counterattack
    if(this->getDamage()<=0){
        cout<<this->get_name()<<" is DEAD"<<endl<<endl;
        return rob;//rob wins
    }
    return fight(rob); //Repeat to continue the challenge until a winner emerges
}
