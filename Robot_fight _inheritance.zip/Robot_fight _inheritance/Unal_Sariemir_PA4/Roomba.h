#ifndef ROOMBA_H
#define ROOMBA_H
#include"Robot.h"
class Roomba:public Robot{
public:
    Roomba();
    Roomba(World *wrld,int newType,int NewStrength,int NewHit,std::string name);
    int getDamage()const override;//Getter for damage (random damage calculation based on Roomba's strength)
    int getHitpoint()const override;//Return HitPoint
    std::string get_name()const override;//Return name
    void setHitpoint(int newHit)override;//Set new HitPoint
    ~Roomba();
};

#endif