#include"World.h"    
#include"Kamikaze.h" 
#include"Bulldozer.h"
#include"Roomba.h"
#include"Humanic.h"
#include"Optimus.h"
#include"Robocop.h"
#include<iostream>   
#include<ctime>
#include<cstdlib>
const int kamikaze = 4;
const int bulldozer = 3;
const int roomba = 2;
const int robocop = 1;
const int optimusPrime = 0;

const int Initial_Count = 5;
using namespace std;
// Function to create the world and populate it with robots
void create_world(World &w1){
    // Variables to keep track of the number of each type of robot
    int kamikaze_count = 0;
    int bulldozer_count = 0;
    int roomba_count = 0;
    int optimusprime_count = 0;
    int robocop_count = 0;
    while(kamikaze_count < Initial_Count){
        // Loop to create Kamikaze robots
        int x = rand() % WORLDSIZE;
        int y = rand() % WORLDSIZE;
        if (w1.getAt(x, y) == nullptr){
            kamikaze_count++;
            // Create a new Kamikaze object and add it to the world
            Kamikaze* k1 = new Kamikaze(&w1,kamikaze,10,10,"kamikaze_" + std::to_string(kamikaze_count));
            w1.setAt(x, y, k1);
        }
    }
    while(bulldozer_count<Initial_Count){
        // Loop to create Bulldozer robots
        int x = rand()%WORLDSIZE;
        int y = rand()%WORLDSIZE;
        if(w1.getAt(x,y)==nullptr){
            bulldozer_count++;
            BullDozer *b1 = new BullDozer(&w1,bulldozer,50,200,"bulldozer_" + std::to_string(bulldozer_count));
            w1.setAt(x,y,b1);
        } 
    }
    while(roomba_count<Initial_Count){
        // Loop to create Roomba robots
        int x = rand()%WORLDSIZE;
        int y = rand()%WORLDSIZE;
        if(w1.getAt(x,y)==nullptr){
            roomba_count++;
            Roomba *r1 = new Roomba(&w1,roomba,3,10,"roomba_" + std::to_string(roomba_count));
            w1.setAt(x,y,r1);
        } 
    }
    while(optimusprime_count<Initial_Count){
        // Loop to create Optimus Prime robots
        int x = rand()%WORLDSIZE;
        int y = rand()%WORLDSIZE;
        if(w1.getAt(x,y)==nullptr){
            optimusprime_count++;
            Optimus *o1 = new Optimus(&w1,optimusPrime,100,100,"optimusPrime_" + std::to_string(optimusprime_count));
            w1.setAt(x,y,o1);
        } 
    }
    while(robocop_count<Initial_Count){
        // Loop to create Robocop robots
        int x = rand()%WORLDSIZE;
        int y = rand()%WORLDSIZE;
        if(w1.getAt(x,y)==nullptr){
            robocop_count++;
            Robocop *rb1 = new Robocop(&w1,robocop,30,40,"robocop_" + std::to_string(robocop_count));
            w1.setAt(x,y,rb1);
        } 
    }
    
}
int main(){
    World w1;//Create a new World object
    srand(time(0));
    create_world(w1);//Create the world and populate it with robots
    while(!w1.control()){
        //Run the simulation until only one robot remains in the world
        w1.simulation();
    }
    w1.Display();//Display the winners
    
    return 0;
}
