#include"Optimus.h"
Optimus::Optimus():Humanic(){}
Optimus::Optimus(World *wrld,int newType,int newStrength,int newHit,std::string name)
    :Humanic(wrld,newType,newStrength,newHit,name){}
Optimus::~Optimus(){}
std::string Optimus::get_name()const{return name;}//Retturn name
int Optimus::getHitpoint()const{return hit_point;}///Return HitPoint
void Optimus::setHitpoint(int newHit){hit_point = newHit;}//Set the new HitPoint

int Optimus::getDamage()const{//Getter for damage calculation (inherits from Humanic)
    int damage;
    damage = rand()%strength+1;//Random damage within strength range
    //Check for special attacks
    if(strong_attack())
        damage = strength*2;//Double damage for strong attack
    else if(tactical_nuke_attack())
        damage = damage+50;//Additional 50 damage for tactical nuke attack
    return damage;
}
int Optimus::tactical_nuke_attack()const{
    //Check if a tactical nuke attack occurs (10% chance for additional 50 damage)
    int number;
    number = rand()%100+1;
    if(number<=10)
        return 1;//Return 1 if tactical nuke attack occurs
    return 0;
}
int Optimus::strong_attack()const{
    //Check if a strong attack occurs (15% chance for double damage)
    int number;
    number = rand()%100+1;
    if(number<=15)
        return 1;//Return 1 if strong attack occurs
    return 0;
}