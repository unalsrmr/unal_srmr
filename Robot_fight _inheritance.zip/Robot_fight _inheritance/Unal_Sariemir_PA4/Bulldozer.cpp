#include"Bulldozer.h"
#include<cstdlib>
BullDozer::BullDozer():Robot(){}
BullDozer::BullDozer(World *wrld,int newType,int newStrength,int NewHit,std::string name)
    :Robot(wrld,newType,newStrength,NewHit,name){}
BullDozer::~BullDozer(){}
std::string BullDozer::get_name()const{return name;}//Return name
int BullDozer::getHitpoint()const{return hit_point;}//Return Hit Point
void BullDozer::setHitpoint(int newHit){hit_point = newHit;}//Set new HitPoint 
int BullDozer::getDamage()const{//Return damage
    int damage;
    damage = rand()%strength+1;
    return damage;
}
