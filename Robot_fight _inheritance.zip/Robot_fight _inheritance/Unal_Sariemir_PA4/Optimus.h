#ifndef OPTIMUS_H
#define OPTIMUS_H
#include"Humanic.h"
class Optimus:public Humanic{
public:
    Optimus();
    Optimus(World *wrld,int newType,int newStrength,int newHit,std::string name);
    int getDamage()const override;//Return damage
    std::string get_name()const override;//Return name
    int getHitpoint()const override;//Return HitPoint
    int tactical_nuke_attack()const override;//Return 1 if tactical nuke attack occurs
    int strong_attack()const;//Return 1 if strong attack occurs
    void setHitpoint(int newHit)override;//Set new HitPoint
    ~Optimus();
};

#endif