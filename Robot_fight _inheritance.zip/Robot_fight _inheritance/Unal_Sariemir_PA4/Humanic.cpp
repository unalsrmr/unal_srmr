#include"Humanic.h"
Humanic::Humanic():Robot(){}
Humanic::Humanic(World *wrld,int newType,int newStrength,int newHit,std::string name)
    :Robot(wrld,newType,newStrength,newHit,name){}
Humanic::~Humanic(){}
