#include"Robocop.h"
Robocop::Robocop():Humanic(){}
Robocop::Robocop(World *wrld,int newType,int newStrength,int newHit,std::string name)
    :Humanic(wrld,newType,newStrength,newHit,name){}
Robocop::~Robocop(){}
std::string Robocop::get_name()const{return name;}
void Robocop::setHitpoint(int newHit){hit_point = newHit;}
int Robocop::getHitpoint()const{return hit_point;}
int Robocop::getDamage()const{
    int damage;
    damage = rand()%strength+1;
    if(tactical_nuke_attack())
        damage = damage+50;//Additional 50 damage for tactical nuke attack
    return damage;
}
int Robocop::tactical_nuke_attack()const{
    //Check if a tactical nuke attack occurs (10% chance for additional 50 damage)
    int number;
    number = rand()%100+1;
    if(number<=10)
        return 1;//Return 1 if tactical nuke attack occurs
    return 0;
}