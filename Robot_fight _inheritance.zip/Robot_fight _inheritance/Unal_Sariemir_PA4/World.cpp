#include "World.h"
World::World(){
    //Initialize the grid with nullptr
    for (int i = 0; i < WORLDSIZE; i++) {
        for (int j = 0; j < WORLDSIZE; j++) {
            grid[i][j] = nullptr;
        }
    }
}
World::~World(){
    //Delete all dynamically allocated robots in the grid
    for(int i = 0;i<WORLDSIZE; i++){
        for(int j = 0; j < WORLDSIZE;j++){
            if(grid[i][j] != nullptr){
                delete grid[i][j];
                grid[i][j] = nullptr;
            }
        }
    }
}
Robot* World::getAt(int x, int y){
    //Return the robot at coordinates (x, y) if within valid range
    if(x>= 0&&x<WORLDSIZE&&y>=0&&y<WORLDSIZE)
        return grid[x][y];
    return nullptr;
}

void World::setAt(int x,int y,Robot* rob){
    grid[x][y] = rob;   //Set the robbot^s coordinats
}

void World::Display(){//Display the winner robot's name and hit points
    bool no_winner = true;
    for(int i = 0; i < WORLDSIZE;i++){
        for(int j = 0; j < WORLDSIZE;j++){
            if(grid[i][j] != nullptr){
                cout<<grid[i][j]->get_name()<<"("<<grid[i][j]->getHitpoint()<<") WON"<<endl;
                no_winner = false;
                break;
            }
        }
    }
    if(no_winner){cout<<"THERE IS NO WINNER!"<<endl;}

}
bool World::control()const{//Check if only one robot remains in the world
    int count = 0;
    for(int i=0;i<WORLDSIZE;i++){
        for(int j=0;j<WORLDSIZE;j++){
            if(grid[i][j]!=nullptr){
                count++;
            }
        }
    }
    return(count<=1);//is remain one robot?
}
//Reset the moved flag for all robots as FALSE
void World::simulation(){
    for(int i=0;i<WORLDSIZE;i++){
        for(int j=0;j<WORLDSIZE;j++){
            if(grid[i][j]!=nullptr){
                grid[i][j]->setMoved(false);
            }
        }
    }
    // Perform movement and combat simulation for each robot
    for(int i=0;i<WORLDSIZE;i++){
        for(int j=0;j<WORLDSIZE;j++){
            if((getAt(i,j)!=nullptr)&&!grid[i][j]->getMoved()){
                int dir;
                dir = rand()%4+1;//Random direction
                dir = this->again(i,j,dir);//Handle edge cases
                grid[i][j]->move(i,j,dir,this);//Move the robot
            }
        }
    }
}

int World::again(int i, int j, int dir){//Determine a valid direction for movement if the initial direction is out of bounds
    int num = dir; 
    bool flag = true;
    while(flag){//Handle edge cases (robots at borders or corners)
        if(num == 1&&j==0){//LEFT
            do{
                num = rand()%4+1;
            }while (num == 1);
        }
        else if(num == 2&&i==0){//TOP
            do{
                num = rand()%4+1;
            }while (num == 2); 
        }
        else if(num == 3&&j==WORLDSIZE-1){//RİGHT 
            do{
                num = rand()%4+1;
            }while (num == 3); 
        } 
        else if(num == 4&&i==WORLDSIZE- 1){//BOTTOM
            do{
                num = rand()%4+1;
            }while(num == 4); 
        }
        else{
            flag = false;
        }
    }
    return num;
}