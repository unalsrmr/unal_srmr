#ifndef HUMANIC_H
#define HUMANIC_H
#include"Robot.h"
class Humanic:public Robot{
public:
    Humanic();
    Humanic(World *wrld,int newType,int newStrength,int newHit,std::string name);
    virtual int tactical_nuke_attack()const = 0;//For OptimusPrime and Robocop
    ~Humanic();
};

#endif
