#include"Kamikaze.h"
Kamikaze::Kamikaze()
    : Robot(){}

Kamikaze::Kamikaze(World* wrld,int newType,int newStrength,int newHit,std::string name)
    : Robot(wrld,newType,newStrength,newHit,name){}
int Kamikaze::getDamage()const{return hit_point;}//Return the damage which equal to its hitpoint
int Kamikaze::getHitpoint()const{return hit_point;}//Return for Hit Point
std::string Kamikaze::get_name()const{return name;}//Return name
void Kamikaze::setHitpoint(int newHit){hit_point = newHit;}//Set the new Hit Point (always 0 for Kamikaze)
Kamikaze::~Kamikaze(){}