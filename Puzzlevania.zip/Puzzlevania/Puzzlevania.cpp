#include<iostream>
#include<ctime>
#include"Puzzlevania.h"
void Puzzlevania::is_won(){
    win = win+1;
}
int Puzzlevania::how_many_won(){
    return win;
}
Puzzlevania::Puzzlevania(int win_value){
    win = win_value;
}
int Puzzlevania::get_num(){
    return num;
}
void Puzzlevania::set_isdead(){
    is_dead = true;
}
void Puzzlevania::start(){
    is_dead = false;
}
void Puzzlevania::Aaron_func(){
    num = rand()%3;
}
void Puzzlevania::Bob_func(){
    num = rand()%2;
}
void Puzzlevania::Charlie_func(){
    num = rand()%1;
}
bool Puzzlevania::get_isdead(){
    return is_dead;
}
void func(Puzzlevania &Aaron,Puzzlevania &Bob,Puzzlevania &Charlie,int &draw){
    for(int i=0;i<10000;i++){
        Aaron.start();
        Bob.start();
        Charlie.start();
        Aaron.Aaron_func();
        if(Aaron.get_num()==0){
            Charlie.set_isdead();
        }
        Aaron.Aaron_func();
        if(!Charlie.get_isdead()){/*hayattaysa*/
            if(Aaron.get_num()==0){
                Charlie.set_isdead();
            }
        }
        else if(!Bob.get_isdead()){
            Bob.set_isdead();
        }
        if(!Bob.get_isdead()){
            Bob.Bob_func();
            if(Bob.get_num()==0){
                if(!Charlie.get_isdead()){
                    Charlie.set_isdead();
                }
                else if(!Aaron.get_isdead()){
                    Aaron.set_isdead();
                }
            }
            Bob.Bob_func();
            if(Bob.get_num()==0){
                if(!Charlie.get_isdead()){
                    Charlie.set_isdead();
                }
                else if(!Aaron.get_isdead()){
                    Aaron.set_isdead();
                }
            }
        }
        if(!Charlie.get_isdead()){
            if(!Aaron.get_isdead()){
                Aaron.set_isdead();
            }
            if(!Bob.get_isdead()){
                Bob.set_isdead();
            }
        }
        if(!Charlie.get_isdead()&&Bob.get_isdead()&&Aaron.get_isdead()){
            Charlie.is_won();
        }
        else if(!Bob.get_isdead()&&Aaron.get_isdead()&&Charlie.get_isdead()){
            Bob.is_won();
        }
        else if(!Aaron.get_isdead()&&Charlie.get_isdead()&&Bob.get_isdead()){
            Aaron.is_won();
        }
        else
            draw++;
    }
}