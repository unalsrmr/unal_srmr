#include<iostream>
#include<ctime>
#include"Puzzlevania.h"
using namespace std;
void func(Puzzlevania &Aaron,Puzzlevania &Bob,Puzzlevania &Charlie,int &draw);
int main(){
    srand(time(0));
    Puzzlevania Aaron(0),Bob(0),Charlie(0);
    int draw = 0;
    func(Aaron,Bob,Charlie,draw);
    cout<<"Aaron wons "<<Aaron.how_many_won()<<"/"<<10000<<endl;
    cout<<"Bob wons "<<Bob.how_many_won()<<"/"<<10000<<endl;
    cout<<"Charlie wons "<<Charlie.how_many_won()<<"/"<<10000<<endl;
    cout<<"Draws "<<draw<<"/"<<10000<<endl;
    if((Aaron.how_many_won()>Bob.how_many_won())&&(Aaron.how_many_won()>Charlie.how_many_won())){
        cout<<"Aaron is Champion"<<endl;
    }
    else if((Bob.how_many_won()>Charlie.how_many_won())&&(Bob.how_many_won()>Aaron.how_many_won())){
        cout<<"Bob is Champion "<<endl;
    }
    else if((Charlie.how_many_won()>Bob.how_many_won())&&(Charlie.how_many_won()>Aaron.how_many_won())){
        cout<<"Charlie is Champion "<<endl;
    }
}