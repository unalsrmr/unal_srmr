#include<iostream>
class Puzzlevania{
    private:
        bool is_dead=false;/*yaşıyor*/
        int num;
        int win;
    public:
        void Aaron_func();
        void Bob_func();
        void Charlie_func();
        void set_isdead();
        int get_num();
        bool get_isdead();/*return is_dead*/
        void start();
        Puzzlevania(int win_value);
        void is_won();
        int how_many_won();
};