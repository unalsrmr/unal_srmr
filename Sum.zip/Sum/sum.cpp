#include<iostream>
#include<cstring>
#include"sum.h"
using namespace std;
void sum::get_num(char *arr1,char *arr2){
    reverse(num1,arr1);
    reverse(num2,arr2);
}
void sum::reverse(char*reverse,char *arr){
    char reversed[20];
    int count = 0;
    for(int i=strlen(arr)-1;i>=0;i--){
        reversed[count] = arr[i];
        count++;
    }
    reversed[count] = '\0';
    strcpy(reverse,reversed);
}
void sum::output(){
    cout<<num1<<" + "<<num2<<" = ";
}
void sum::set_num(char *arr1,char *arr2){
    strcpy(num1,arr1);
    strcpy(num2,arr2);
}
void sum::total_sum(){
    int carry=0,i,tot;
    int max = strlen(num1) > strlen(num2) ? strlen(num1) : strlen(num2);
    for(i=0;i<max;i++){
        int digit1 = (i < strlen(num1)) ? num1[i] - '0' : 0;
        int digit2 = (i < strlen(num2)) ? num2[i] - '0' : 0;
        int sum = digit1 + digit2 + carry;
        total[i] = sum%10;
        carry = sum/10;
    }
    if(carry!=0){
        total[i] = carry;
        i++;
    }
    for(int k=i-1;k>=0;k--){
        cout<<total[k];
    }
    cout<<endl;
}