#include<iostream>
#include<cstring>
#include"sum.h"
using namespace std;
int main(){
    sum s1;
    char arr1[20],arr2[20];
    cin>>arr1>>arr2;
    s1.set_num(arr1,arr2);
    s1.output();
    s1.get_num(arr1,arr2);
    s1.total_sum();
}