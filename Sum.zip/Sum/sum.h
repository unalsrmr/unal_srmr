#include<iostream>
class sum{
    private:
        char num1[20];
        char num2[20];
        int total[21];
    public:
        void get_num(char *arr1,char *arr2);
        void reverse(char *reverse,char *arr1);
        void output();
        void total_sum();
        void set_num(char *arr1,char *arr2);
};