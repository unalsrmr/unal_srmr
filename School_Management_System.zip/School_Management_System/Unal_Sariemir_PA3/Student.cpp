#include "Student.h"
#include "Course.h"
#include "SchoolManagerSystem.h"
#include <iostream>
using namespace std;

int Student::student_count = 0;
//Construtor
Student::Student(const string &name_val){
    courses_register = new Course*[5];
    name = name_val;
}
//Destructor
Student::~Student(){
    delete[] courses_register;
}
//Getter function for name
string Student::getName()const{
    return name;
}
void Student::register_to_course(Course **cours){//represents an array of pointers
    cout<<"0 up"<<endl; //Menu for returning backv
    int i,j,number=0;
    //Check if the student is not registered to any course
    if(number_of_regitereted_student==0){
        for(i=0;i<Course::course_count;i++){
            cout<<i+1<<" "<<cours[i]->getName()<<endl;
            number++;//Count the number of available courses
        }
    }
    else{//display the available courses
        for(i=0;i<Course::course_count;i++){
            bool control = false;
            //Check if the student is already registered to the current course
            for(j=0;j<number_of_regitereted_student;j++){
                if(courses_register[j]->getName()==cours[i]->getName()){
                    control = true;
                }
            }
            //If the student is not registered to the current course display it
            if(!control){
                cout<<number+1<<" "<<cours[i]->getName()<<endl;
                number++;
            }
        }
    }
    int num;
    cout<<">> ";
    cin>>num;
    //Check for invalid input
    if((cin.fail()||num < 0 || num > number)){
        cin.clear(); //Clear error state
        while(cin.get() != '\n');//Clear input buffer
        register_to_course(cours);
        return;
    }
    //Register the student to the selected course
    if(num!=0){
        int selected_number = num-1;//Adjust index to start from 0
        courses_register[number_of_regitereted_student] = cours[selected_number+number_of_regitereted_student];
        number_of_regitereted_student++;
        //Adjust the array size if necessary
        if(number_of_regitereted_student%5==0){
            arrange_size(number_of_regitereted_student);
        }
        //Register the course to the student
        courses_register[number_of_regitereted_student-1]->register_the_course(this);
    }
}
void Student::arrange_size(int &num){
    int new_size = num*2;
    Course **new_courses = new Course*[new_size];
    //Initialize the new array with nullptr
    for(int i=0;i<new_size;i++){
        new_courses[i] = nullptr;
    }
    //Copy the existing courses to the new array
    for(int i=0;i<num;i++){
        new_courses[i] = courses_register[i];
        courses_register[i] = nullptr;
    }
    //Delete the old array and assign the new one
    delete[] courses_register;
    courses_register = new_courses;
}
void Student::make_nul(Course *cour){
    //When I delete the course delete it from that student reference
    int i;
    for(i=0;i<number_of_regitereted_student;i++){
        if(cour->getName()==courses_register[i]->getName()){
            break;
        }
    }
    //Set the course pointer to nullptr and shift the elements
    courses_register[i] = nullptr;
    for(int j=i;j<number_of_regitereted_student-1;j++){
        courses_register[j] = courses_register[j+1];
    }
    courses_register[number_of_regitereted_student - 1] = nullptr;
    number_of_regitereted_student--;
}
void Student::drop_course(){
    //Check if the student is registered to any course
    if(number_of_regitereted_student>0){
        cout<<"0 up"<<endl;
        //Print the registered courses
        for(int i=0;i<number_of_regitereted_student;i++){
            cout<<i+1<<" "<<courses_register[i]->getName()<<endl;
        }
        int num;
        cin>>num;
        //Check for invalid input
        if((cin.fail()||num < 0||num>number_of_regitereted_student)){
            cin.clear(); //Clear error state
            while (cin.get() != '\n') ;//Clear input buffer
            drop_course();
            return;
        }
        //Drop the selected course
        if(num!=0){
            int number = num-1;
            courses_register[number]->drop_the_course(this);
            courses_register[number] = nullptr;
            for(int i=number;i<number_of_regitereted_student-1;i++){
                courses_register[i] = courses_register[i+1];
            }
            courses_register[number_of_regitereted_student - 1] = nullptr;
            number_of_regitereted_student--;
        }

    }
}