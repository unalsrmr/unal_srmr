#include"Course.h"
#include<string>
#include"Student.h"
using namespace std;
int Course::course_count = 0;
Course::Course(const string &name_val){
    //Constructor initializes the course name and allocates memory for students register
    students_register = new Student*[5];
    name = name_val;
}
Course::~Course(){
    //Destructor deallocates memory for students
    delete[]students_register;
}
string Course::getName()const{//Getter function to retrieve the course name
    return name;
}
//Register a student to the course
void Course::register_the_course(Student *stu){
    students_register[number_of_registereed_student] = stu;
    number_of_registereed_student++;
    //If the number of registered students is a multiple of 5,increase the array size
    if(number_of_registereed_student%5==0){
        arrange_size(number_of_registereed_student);
    }
}
//Print all students registered to the course
void Course::print_all_student_which_registered(){
    for(int i=0;i<number_of_registereed_student;i++){
        cout<<i+1<<" "<<students_register[i]->getName()<<endl;
    }
}
//Resize the students array to accommodate more students
void Course::arrange_size(int &num){
    int new_size = num*2;
    Student **new_student = new Student*[new_size];
    for(int i=0;i<new_size;i++){
        new_student[i] = nullptr;
    }
    for(int i=0;i<num;i++){
        new_student[i] = students_register[i];
    }
    students_register = new_student;
}    
//Remove a student from the course
void Course::drop_the_course(Student *stu){
    int i;
    //Find the index of the student in the array
    for(i=0;i<number_of_registereed_student;i++){
        if(stu->getName()==students_register[i]->getName()){
            break;
        }
    }
    //Remove the student from the array and adjust the array
    students_register[i] = nullptr;
    for(int j=i;j<number_of_registereed_student-1;j++){
        students_register[j] = students_register[j+1];
    }
    students_register[number_of_registereed_student-1] = nullptr;
    number_of_registereed_student--;
}
//If a student is deleted remove all of their registrations from courses
void Course::make_null(Student *stu){
    int i;
    //Find the registration of the student in the course
    for(i=0;i<number_of_registereed_student;i++){
        if(stu->getName()==students_register[i]->getName()){
            //Remove the student's registration
            students_register[i] = nullptr;
            break;
        }
    }
    students_register[i] = nullptr;
    //Shift the remaining registrations to fill the gap
    for(int j=i;j<number_of_registereed_student-1;j++){
        students_register[j] = students_register[j+1];
    }   
    //Set the last registration as nullptr and decrement the count
    students_register[number_of_registereed_student-1] = nullptr;
    number_of_registereed_student--;
}