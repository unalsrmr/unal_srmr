#include"SchoolManagerSystem.h"
#include"Student.h"
#include"Course.h"
#include<iostream>
using namespace std;
System::System(){
    //Allocate memory for an array of pointers to students and courses
    students = new Student*[5];
    courses = new Course*[5];
}
void System::main_menu(){
    cout<<"0 exit\n1 student\n2 course\n3 list_all_students\n4 list_all_courses\n>> ";
    char num;
    cin>>num;
    if(!(num >= '0' && num <= '4')){
        main_menu();
    }
    switch(num){
        case '0':
            break;
        case '1':
            student_menu();
            break;
        case '2':
            course_menu();
            break;
        case '3':
            list_all_student();
            break;
        case '4':
            list_all_courses();
            break;
    }
}
void System::student_menu(){
    cout<<"0 up\n1 add_student\n2 select_student\n>> ";
    char num;
    cin>>num;
    //Check if the input is valid
    if(!(num >= '0' && num <= '2')){
        student_menu();
    }
    switch(num){
        case '0':
            main_menu();
            break;
        case '1':
            add_student();
            break;
        case '2':
            select_student();
            break;
    }
}
void System::add_student(){
    string name;
    cin.ignore();
    cout<<">> ";
    getline(cin,name);
    if((Student::student_count+1)%5==0){/*5 ve katlarında*/
        arrange_new_size(Student::student_count);
    }
    //Create a new Course object with the given name and add it to the courses array
    students[Student::student_count] = new Student(name);
    Student::student_count++;
    student_menu();
}
void System::select_student(){
    string name;
    cout<<">> ";
    cin.ignore();
    getline(cin,name);
    bool exist = false;int i;
    //Check if the entered student name exists in the system
    for(i=0;i<Student::student_count;i++){
        if(students[i]->getName()==name){
            exist = true;
            break;
        }
    }
    if(exist)
    //If the student exists select the student otherwise go back to the student menu
        selected_student(students[i]);
    else
        student_menu();
}
void System::selected_student(Student *student){
    cout<<"0 up\n1 delete_student\n2 add_selected_student_to_a_course\n";
    cout<<"3 drop_selected_student_from_a_course"<<endl;
    char num;
    cout<<">> ";
    cin>>num;
    if(!(num>='0'&&num<='3')){
        selected_student(student);
        return;
        //Added return to terminate the function after the recursive call
    }
    switch(num){
        case '0':
            student_menu();
            break;
        case '1':
            delete_student(student);
            break;
        case '2':
            add_to_a_course(student);
            selected_student(student);
            break;
        case '3':
            drop_from_course(student);
            selected_student(student);
            break;
    }
}
void System::delete_student(Student *student){
    for(int i=0;i<Course::course_count;i++){
        courses[i]->make_null(student);
    }
    int num = Student::student_count;
    for(int i = 0; i < num; i++){
        // Find the student to delete from the system
        if (student->getName() == students[i]->getName()){
            //Shift the elements in the array to fill the gap
            for (int j = i;j<(num - 1); j++){
                students[j] = students[j + 1];
            }
            break;
        }
    }
    // Decrement the student count
    Student::student_count--;
    student_menu();
}
void System::list_all_student(){
    for(int i=0;i<Student::student_count;i++){
        cout<<i +1<<" "<<students[i]->getName()<<endl;
    }
    main_menu();
}
void System::add_to_a_course(Student *student){
    student->register_to_course(courses);
}
void System::course_menu(){
    // Display menu options for the course menu
    cout<<"0 up\n1 add_course\n2 select_course\n>> ";
    char num;
    cin>>num;
    if(!(num >= '0' && num <= '2')){
        course_menu();
    }
    switch(num){
        case '0':
            main_menu();
            break;
        case '1':
            add_course();
            break;
        case '2':
            select_course();
            break;
    }
}
void System::add_course(){
    string name;
    cin.ignore();//Ignore any previous newline characters in the input buffer
    cout<<">> ";
    getline(cin,name);
    //If the current number of courses is a multiple of 5, expand the size of the courses array
    if((Course::course_count+1)%5==0){
        arrange_new_size_c(Course::course_count);
    }
    courses[Course::course_count] = new Course(name);
    Course::course_count++;
    course_menu();
}
void System::select_course(){
    string name;
    cout<<">> ";
    cin.ignore();
    getline(cin,name);
    bool exist=false;int i;
    //Check if the entered course name exists
    for(i=0;i<Course::course_count;i++){
        if(name==courses[i]->getName()){
            exist = true;
            break;
        }
    }
    //If the course exists, select it, otherwise, go back to the course menu
    if(exist)
        selected_course(courses[i]);
    else
        course_menu();
}
void System::selected_course(Course *cour){
    // Function displays the options for the selected course
    cout<<"0 up\n1 delete_course\n2 list_students_registered_to_the_selected_course"<<endl;
    char num;
    cout<<">> ";
    cin>>num;
    //Loop ensures the user makes a valid selection
    if(!(num>='0'&&num<='2')){
        selected_course(cour);
    }
    //Performs actions based on user's selection
    switch(num){
        case '0':
            course_menu();
            break;
        case '1':
            delete_course(cour);
            break;
        case '2':
            print_registered_student(cour);
            course_menu();
            break;
    }
}
void System::delete_course(Course *cour){
    //Remove all students from the course
    for(int i=0;i<Student::student_count;i++){
        students[i]->make_nul(cour);
    }
    //Remove the course from the array
    for(int i=0;i<Course::course_count;i++){
        if(cour->getName()==courses[i]->getName()){
            courses[i] = nullptr;
            for(int j=i;j<Course::course_count-1;j++){
                courses[j] = courses[j+1];
            }
            break;
        }
    }
    Course::course_count--;
    course_menu();
}
void System::drop_from_course(Student *student){
    //remove the student from the course
    student->drop_course();
}
void System::arrange_new_size(int &num){
    int new_size = num*2;
    Student**new_students = new Student*[new_size];
    for(int i = 0; i < new_size; i++){
        //Initialize the new student array with nullptr
        new_students[i] = nullptr;
    }
    //Copy the current student array to the newly created array
    for(int i=0;i<Student::student_count;i++){
        new_students[i] = students[i];
    }
    delete[] students;//Free the memory of the old student array
    students = new_students;
}
void System::arrange_new_size_c(int &num){
    int new_size = num*2;
    Course **new_course = new Course*[new_size];
    // Initialize new_course array with nullptrs
    for(int i=0;i<new_size;i++){
        new_course[i] = nullptr;
    }
    // Copy existing courses to new_course array
    for(int i=0;i<num;i++){
        new_course[i] = courses[i];
    }
    delete[] courses;//Delete old courses array
    courses = new_course;//Assign new_course array to courses pointer
}
void System::list_all_courses(){
    for(int i=0;i<Course::course_count;i++){
        cout<<i+1<<" "<<courses[i]->getName()<<endl;
    }
    main_menu();
}

void System::print_registered_student(Course *cour){
    //Print all students registered for the selected course
    cour->print_all_student_which_registered();
}
System::~System(){
    //Destructor to release memory allocated for students and courses
    delete[] students;
    delete[] courses;
}