#ifndef Course_h
#define Course_h

#include<iostream>
#include<string>
using namespace std;
class Student;
class System;
class Course {
private:
    string name;
    Student **students_register;//Array of pointers to registered students
    int number_of_registereed_student = 0;//Number of registered students
public:
    friend class Student;//Allowing Student class to access private members
    friend class System;//Allowing System class to access private members
    static int course_count;//Count the number of course objects
    Course(const string &name_val);
    ~Course();
    string getName() const;//Getter function for course name
    void register_the_course(Student *stu);//register a student to the course
    void drop_the_course(Student *stu);//drop a student from the course
    void print_all_student_which_registered();//print all registered students
    void arrange_size(int &num);//resize the students array
    void make_null(Student *stu);//make the students array null when course is deleted
};

#endif
