#include<iostream>
#include<string>
#include<sstream>
#include"Student.h"
#include"Course.h"
#include"SchoolManagerSystem.h"
using namespace std;
int main(){
    System s1;
    s1.main_menu();
    return 0;
}
