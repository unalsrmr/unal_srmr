#ifndef Student_h
#define Student_h

#include<iostream>
#include<string>
using namespace std;
class Course;
class Student{
private:
    string name;
    Course **courses_register;//Pointer to an array of Course pointers for registration
    int number_of_regitereted_student = 0;//Number of registered courses
public:
    friend class System;//Allow System class to access private members
    friend class Course;//Allow Course class to access private members
    static int student_count;//Static member to count the number of students
    Student(const string &name_val);
    ~Student();
    string getName()const;//getter function for name
    void register_to_course(Course **cours);//register the student to courses
    void arrange_size(int &num);//arrange the size of the courses array
    void make_nul(Course *cour);//make a course reference null when the course is deleted
    void drop_course();//drop a course
};

#endif 