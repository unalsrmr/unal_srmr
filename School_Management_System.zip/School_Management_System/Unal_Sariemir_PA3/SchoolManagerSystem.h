#ifndef SchoolManagerSystem_h
#define SchoolManagerSystem_h

#include<iostream>
#include"Student.h"
using namespace std;
class System{
    private:
        Student **students; //Pointer to an array of student pointers
        Course **courses;   //Pointer to an array of course pointers
    public:
        friend class Course;
        friend class Student;
        System();            //Constructor
        ~System();           //Destructor
        void main_menu();    //Display the main menu and handle user input
        void student_menu(); //Display the student menu and handle user input
        void add_student();  //Add a new student
        void select_student();  //Select a student from the list
        void selected_student(Student *student);  //Handle selected student actions
        void list_all_student();  //List all students
        void delete_student(Student *student);  //Delete a student
        void course_menu();  //Display the course menu and handle user input
        void list_all_courses();  //List all courses
        void add_course();  //Add a new course
        void select_course();  //Select a course from the list
        void selected_course(Course *cour);  //Handle selected course actions
        void delete_course(Course *cour);  //Delete a course
        void add_to_a_course(Student *student);  //Add a student to a course
        void arrange_new_size(int &num);  //Arrange new size for the student array
        void arrange_new_size_c(int &num);  //Arrange new size for the course array
        void print_registered_student(Course *cour);  //Print registered students for a course
        void drop_from_course(Student *student);  //Drop a student from a course
};

#endif